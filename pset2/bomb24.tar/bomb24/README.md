CS 61 Problem Set 2
===================

This is bomb #24.

It belongs to hcerbone (hcerbone@college.harvard.edu).
